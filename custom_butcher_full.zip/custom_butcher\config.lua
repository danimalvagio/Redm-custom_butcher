Config = {}

-- Items Configuration
Config.TableItem = "butcher_table"
Config.SpoiledItem = "meat_spoiled"

Config.Language = {
    -- Server logs
    dbChecking = "^2[%s] Checking and inserting missing items into database...^0",
    dbInserted = "^3[%s] Item Inserted: %s^0",
    testUsed = "^2[custom_butcher] testbutcher command used by source: %s^0",
    
    -- Client notifications
    itemReceived = "Items received for testing!",
    meatSpoiled = "Some of your raw meat (%s) has spoiled!",
    butcheredSuccess = "You butchered the animal.",
    noCarcass = "You have no carcasses to butcher.",
    createdOn = "Created on: %s",
    
    -- Client UI
    tablePlaced = "Butcher table placed.",
    tablePickedUp = "Butcher table picked up.",
    cancelPlacement = "Placement cancelled."
}

-- Spoilage Times (in REAL minutes)
Config.SpoilTimer = 120 -- Tempo di deperimento in minuti (2 ore)
Config.CheckInterval = 60000 -- Controlla ogni minuto (60000 ms)

-- Probability of wild animal attack (Percentage 1-100) per predator check
Config.PredatorChance = 10 -- 10% di possibilità
Config.PredatorCheckInterval = 120000 -- Controlla ogni 2 minuti (120000 ms)

-- Valid Carcasses that can be butchered
Config.Carcasses = {
    -- Default generic carcasses
    ["animal_carcass"] = {
        reward_items = {
            { item = "meat_medium", amount = 2 }
        }
    },
    ["carcass_small"] = {
        reward_items = {
            { item = "meat_small", amount = 1 },
            { item = "pelt_small", amount = 1 }
        }
    },
    ["carcass_medium"] = {
        reward_items = {
            { item = "meat_medium", amount = 2 },
            { item = "pelt_medium", amount = 1 }
        }
    },
    ["carcass_large"] = {
        reward_items = {
            { item = "meat_large", amount = 3 },
            { item = "pelt_large", amount = 1 }
        }
    }
}

-- Target and Prompt Config
Config.TableProp = "p_table04x"
Config.PromptName = "Butcher Carcass"
Config.PromptKey = 0xCEFD9220 -- E
