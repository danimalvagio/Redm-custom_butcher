local VorpCore = exports.vorp_core:GetCore()
local VorpInv = exports.vorp_inventory:vorp_inventoryApi()

-- Automatica inserzione nel DB all'avvio
AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
      return
    end
    print('^2['..resourceName..'] Created by danimalvagio^0')
    print(string.format(Config.Language.dbChecking, resourceName))
    
    local items = {
        {item = 'butcher_table', label = 'Butcher Table', limit = 1, can_remove = 1, type = 'item_standard', usable = 1},
        {item = 'meat_spoiled', label = 'Spoiled Meat', limit = 20, can_remove = 1, type = 'item_standard', usable = 0},
        
        -- Nuovi Item Categorizzati (S/M/L)
        {item = 'meat_small', label = 'Small Meat', limit = 20, can_remove = 1, type = 'item_standard', usable = 1},
        {item = 'meat_medium', label = 'Medium Meat', limit = 20, can_remove = 1, type = 'item_standard', usable = 1},
        {item = 'meat_large', label = 'Large Meat', limit = 20, can_remove = 1, type = 'item_standard', usable = 1},
        
        {item = 'pelt_small', label = 'Small Pelt', limit = 10, can_remove = 1, type = 'item_standard', usable = 0},
        {item = 'pelt_medium', label = 'Medium Pelt', limit = 10, can_remove = 1, type = 'item_standard', usable = 0},
        {item = 'pelt_large', label = 'Large Pelt', limit = 10, can_remove = 1, type = 'item_standard', usable = 0},
        
        {item = 'carcass_small', label = 'Small Carcass', limit = 5, can_remove = 1, type = 'item_standard', usable = 1},
        {item = 'carcass_medium', label = 'Medium Carcass', limit = 2, can_remove = 1, type = 'item_standard', usable = 1},
        {item = 'carcass_large', label = 'Large Carcass', limit = 1, can_remove = 1, type = 'item_standard', usable = 1},

        -- Item legacy per compatibilità
        {item = 'animal_carcass', label = 'Animal Carcass', limit = 2, can_remove = 1, type = 'item_standard', usable = 1}
    }

    for _, i in ipairs(items) do
        -- Controlla se l'item esiste già, altrimenti lo inserisce o aggiorna
        MySQL.query("SELECT item FROM items WHERE item = ?", {i.item}, function(result)
            if not result or #result == 0 then
                MySQL.insert('INSERT INTO items (item, label, `limit`, can_remove, type, usable) VALUES (?, ?, ?, ?, ?, ?)', {
                    i.item, i.label, i.limit, i.can_remove, i.type, i.usable
                }, function(id)
                    print(string.format(Config.Language.dbInserted, resourceName, i.item))
                end)
            else
                -- Forza aggiornamento dei valori chiave in caso siano sbagliati
                MySQL.update('UPDATE items SET label=?, `limit`=?, can_remove=?, type=?, usable=? WHERE item=?', {
                    i.label, i.limit, i.can_remove, i.type, i.usable, i.item
                })
            end
        end)
    end
end)

-- Registrazione Oggetto: Tavolo da Macellaio
VorpInv.RegisterUsableItem(Config.TableItem, function(data)
    local _source = tonumber(data.source)
    -- Tolgo il tavolo dall'inventario
    VorpInv.subItem(_source, Config.TableItem, 1)
    
    -- Notifico il client di piazzare il tavolo
    TriggerClientEvent('custom_butcher:client:placeTable', _source)
end)

-- Evento per Macellare (LITE: nessun sistema di qualità)
RegisterServerEvent('custom_butcher:server:processCarcass')
AddEventHandler('custom_butcher:server:processCarcass', function()
    local source = tonumber(source)
    local foundCarcass = nil
    local carcassKey = nil
    
    -- Ricerca della prima carcassa configurata nell'inventario del giocatore
    for k, v in pairs(Config.Carcasses) do
        local count = VorpInv.getItemCount(source, k)
        if count and count > 0 then
            foundCarcass = k
            carcassKey = v
            break
        end
    end

    if foundCarcass then
        -- Rimuovo la carcassa
        VorpInv.subItem(source, foundCarcass, 1)
        
        -- Assegno i premi (quantità fissa, nessun moltiplicatore di qualità)
        for _, reward in ipairs(carcassKey.reward_items) do
            local metadata = {
                butcher_time = os.time(),
                description = string.format(Config.Language.createdOn, os.date("%d/%m/%Y %H:%M:%S"))
            }
            VorpInv.addItem(source, reward.item, reward.amount, metadata)
        end
        TriggerClientEvent("vorp:TipRight", source, Config.Language.butcheredSuccess, 4000)
    else
        TriggerClientEvent("vorp:TipRight", source, Config.Language.noCarcass, 4000)
    end
end)

-- Sistema di Deperimento Background
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.CheckInterval)
        
        local players = GetPlayers()
        for _, playerId in ipairs(players) do
            playerId = tonumber(playerId)
            if playerId then
                local userInv = VorpInv.getUserInventory(playerId)
                if userInv then
                    local hasSpoiled = false
                    
                    for _, item in ipairs(userInv) do
                        -- Controllo se l'item è un tipo di carne categorizzata
                        local spoilableMeats = {
                            ["meat_small"] = true, ["meat_medium"] = true, ["meat_large"] = true
                        }
                        
                        if spoilableMeats[item.name] then
                            if item.metadata and item.metadata.butcher_time then
                                local currentTime = os.time()
                                local ageInMinutes = (currentTime - item.metadata.butcher_time) / 60
                                
                                -- Se è passato il tempo di spoil
                                if ageInMinutes >= Config.SpoilTimer then
                                    -- Rimuoviamo questo specifico blocco di carne tramite count
                                    VorpInv.subItem(playerId, item.name, item.count, item.metadata)
                                    -- Aggiungiamo carne avariata
                                    VorpInv.addItem(playerId, Config.SpoiledItem, item.count)
                                    TriggerClientEvent("vorp:TipRight", playerId, string.format(Config.Language.meatSpoiled, item.label), 4000)
                                    hasSpoiled = true
                                end
                            end
                        end
                        if item.name == Config.SpoiledItem then
                            hasSpoiled = true
                        end
                    end
                    
                    -- Invio stato al client per decidere se spawnare predatore
                    TriggerClientEvent('custom_butcher:client:updateSpoilStatus', playerId, hasSpoiled)
                end
            end
        end
    end
end)

-- Comando di test per ottenere gli item (solo admin)
RegisterCommand("testbutcher", function(source, args, rawCommand)
    local _source = source
    local Character = VorpCore.getUser(_source).getUsedCharacter
    if Character.group == "admin" then
        print(string.format(Config.Language.testUsed, tostring(_source)))
        VorpInv.addItem(_source, Config.TableItem, 1)
        VorpInv.addItem(_source, "carcass_medium", 1)
        TriggerClientEvent("vorp:TipRight", _source, Config.Language.itemReceived, 4000)
    end
end, false)
