INSERT INTO `items` (`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES
('butcher_table', 'Butcher Table',  1,  1, 'item_standard', 1),
('meat_spoiled',  'Spoiled Meat',  20,  1, 'item_standard', 0),
('carcass_small', 'Small Carcass', 10,  1, 'item_standard', 0),
('carcass_medium','Medium Carcass', 5,  1, 'item_standard', 0),
('carcass_large', 'Large Carcass',  3,  1, 'item_standard', 0),
('meat_small',    'Small Meat',    30,  1, 'item_standard', 1),
('meat_medium',   'Medium Meat',   20,  1, 'item_standard', 1),
('meat_large',    'Large Meat',    15,  1, 'item_standard', 1),
('pelt_small',    'Small Pelt',    20,  1, 'item_standard', 0),
('pelt_medium',   'Medium Pelt',   10,  1, 'item_standard', 0),
('pelt_large',    'Large Pelt',     5,  1, 'item_standard', 0)
ON DUPLICATE KEY UPDATE label=VALUES(label), `limit`=VALUES(`limit`);

