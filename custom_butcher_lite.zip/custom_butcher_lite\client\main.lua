local ActiveTables = {}
local HasSpoiledMeat = false

local ButcherPrompt = nil
local PromptGroup = GetRandomIntInRange(0, 0xffffff)

function SetupPrompt()
    Citizen.CreateThread(function()
        local str = Config.PromptName
        ButcherPrompt = PromptRegisterBegin()
        PromptSetControlAction(ButcherPrompt, Config.PromptKey)
        str = CreateVarString(10, 'LITERAL_STRING', str)
        PromptSetText(ButcherPrompt, str)
        PromptSetEnabled(ButcherPrompt, 1)
        PromptSetVisible(ButcherPrompt, 1)
        PromptSetStandardMode(ButcherPrompt, 1)
        PromptSetGroup(ButcherPrompt, PromptGroup)
        Citizen.InvokeNative(0xC5F428EE08FA7F2C, ButcherPrompt, true)
        PromptRegisterEnd(ButcherPrompt)
    end)
end

RegisterNetEvent('custom_butcher:client:placeTable')
AddEventHandler('custom_butcher:client:placeTable', function()
    local ped = PlayerPedId()
    local x, y, z = table.unpack(GetEntityCoords(ped))
    local heading = GetEntityHeading(ped)

    -- Spawn front of player
    local spawnX = x + (GetEntityForwardX(ped) * 1.5)
    local spawnY = y + (GetEntityForwardY(ped) * 1.5)
    local spawnZ = z - 1.0 

    local propModel = GetHashKey(Config.TableProp)
    RequestModel(propModel)
    
    local timeout = 0
    while not HasModelLoaded(propModel) and timeout < 100 do
        Citizen.Wait(10)
        timeout = timeout + 1
    end

    if HasModelLoaded(propModel) then
        local tableProp = CreateObject(propModel, spawnX, spawnY, spawnZ, true, true, false)
        SetEntityHeading(tableProp, heading)
        PlaceObjectOnGroundProperly(tableProp)
        
        table.insert(ActiveTables, tableProp)
        TriggerEvent("vorp:TipRight", Config.Language.tablePlaced, 4000)
    else
        TriggerEvent("vorp:TipRight", "Error: Table model not found.", 4000)
    end
end)

-- Main Loop to detect tables
Citizen.CreateThread(function()
    SetupPrompt()
    while true do
        Citizen.Wait(0)
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local isNearTable = false
        
        for k, tableProp in pairs(ActiveTables) do
            if DoesEntityExist(tableProp) then
                local tCoords = GetEntityCoords(tableProp)
                local dist = #(coords - tCoords)
                
                if dist < 2.0 then
                    isNearTable = true
                    
                    local promptGroupName = CreateVarString(10, 'LITERAL_STRING', Config.PromptName)
                    PromptSetActiveGroupThisFrame(PromptGroup, promptGroupName)

                    if PromptHasStandardModeCompleted(ButcherPrompt) then
                        -- Player pressed E
                        TriggerServerEvent('custom_butcher:server:processCarcass')
                        Citizen.Wait(2000) -- Cooldown per non spammare
                    end
                end
            end
        end
        
        if not isNearTable then
            Citizen.Wait(500)
        end
    end
end)

-- Receive Spoil Status from server
RegisterNetEvent('custom_butcher:client:updateSpoilStatus')
AddEventHandler('custom_butcher:client:updateSpoilStatus', function(status)
    HasSpoiledMeat = status
end)

-- Predator System Loop
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.PredatorCheckInterval)
        
        if HasSpoiledMeat then
            local chance = math.random(1, 100)
            if chance <= Config.PredatorChance then
                SpawnPredator()
            end
        end
    end
end)

function SpawnPredator()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    
    local models = {
        GetHashKey("A_C_Wolf_Medium"),
        GetHashKey("A_C_Bear_01")
    }
    local model = models[math.random(1, #models)]
    
    RequestModel(model)
    local timeout = 0
    while not HasModelLoaded(model) and timeout < 200 do
        Citizen.Wait(10)
        timeout = timeout + 1
    end
    
    if HasModelLoaded(model) then
        -- Spawn some distance away
        local radius = 25.0
        local angle = math.random() * math.pi * 2
        local spawnX = coords.x + radius * math.cos(angle)
        local spawnY = coords.y + radius * math.sin(angle)
        
        -- Get valid Z with a fallback
        local retval, outZ = GetGroundZAndNormalFor_3dCoord(spawnX, spawnY, coords.z + 50.0)
        if not retval then 
            outZ = coords.z -- fallback to player Z if ground check fails
        end
        
        local predator = CreatePed(model, spawnX, spawnY, outZ, 0.0, true, true, true, true)
        
        -- Essential for RedM entities to be persistent and visible
        SetEntityAsMissionEntity(predator, true, true)
        SetModelAsNoLongerNeeded(model)
        
        -- For Animals, sometimes Outfit Preset is needed to initialize the "look"
        Citizen.Wait(100)
        Citizen.InvokeNative(0x77FF8D35EEC6BBC4, predator, 0, 0) -- SetPedOutfitPreset
        
        SetEntityVisible(predator, true)
        SetPedRelationshipGroupHash(predator, GetHashKey("PVP_REDM_AGGRESSIVE")) -- Ensure he's aggressive
        
        -- Make predator attack player
        TaskCombatPed(predator, ped, 0, 16)
    end
end
